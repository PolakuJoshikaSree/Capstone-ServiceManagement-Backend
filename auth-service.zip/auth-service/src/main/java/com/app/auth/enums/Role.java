package com.app.auth.enums;

public enum Role {
    ADMIN,
    MANAGER,
    TECHNICIAN,
    CUSTOMER
}

